**universe of our products,brands and companies 

Monsters inc.
Web 3 
Ai
Internet of things 
