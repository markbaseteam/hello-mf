[[Electrons-101]]

## **Grid** 🍀

-   Dark store [warehouse] + retail ,2km or short distance radius
-   Warehouse to end point - bots ~ that can transports goods effectively
-   Ground & underground Grid
-   Voltt membership in ~ [//](https://www.taskade.com/v/ZeE835xu1zCpgvky "//")
-   Official brands in store
-   Low markups [Price]
-   3d rendered pitch [kathi blueprint]
-   Xr - App [rotating shelves]
-   Data mine - shopping predictions
-   restocking warehouse via grid with Shipping algorithm
-   Micro cargo
-   Safe Cargo - for human organs [🦆]
- [[Crate]]**