[[Electrons-101]]

# **App -** 🦹‍♂️

-   The Pro app [productivity] with books,podcasts,articles etc
-   _Freemium model_
-   _To do, habit builder, productivity_
-   Negative points - deadline
-   Automate productivity- make.con
-   _Integration with other apps - notion, taskade etc.._
-   _Reward as collectibles [limited edition] 🐌 - play to earn + collecting_
-   _Gamification + friends_
-   _to do task will be integrated example ~ to complete taskade project ~To do pitch deck Incubating mode - Progress bar w/ collectibles_
-   Newt - second brain with consumption, integration, brain layers - books , podcasts, articles etc
- elements (blocks) to make you 
get in the zone!
- [[BacKbench]],[[Ghost]]
- [[xid]] - official personall database - hexb (clpoud stroage)
- content format - format for creators to share with content(youtube,twitter)  
[[Sandwich atomic]] 