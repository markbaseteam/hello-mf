[[Electrons-101]]

## **XR Extended reality [OS]**

-   30% cut [may vary]
-   Services ~ official
-   Shortcut [automation]
-   Health friendly
-   Xverse
-   Tech companies collabs
-   Hexb computing
-   🐦 ❌ Brands ~ pokemon,marvel
-   Game - Pokémon go like thing collectibles , boosted area for real world traffic and revenue stream from that