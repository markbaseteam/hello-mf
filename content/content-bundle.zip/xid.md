encrypted identity database of [[hexb]] 
using zero knowledge technolgy 
