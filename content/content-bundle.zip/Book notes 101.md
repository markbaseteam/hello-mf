Book - notes
	◦	Take notes (hightlights)
	◦	Revisit and revise 
	◦	Category & file (according to topics or interests)
[[when to take note]]
[[Note takers]]
[[life-101]] 
