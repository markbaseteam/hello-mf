[[Electrons-101]]

## **🍧 Pay in monthly intervals**

-   Buy products & services w/ [Perks]
-   W/ Ghost (payroll) , Account , carbon divided - [credit limit]
-   [FR] - w/ terb algorithm
-   12 m - no cost ~ 8%
-   12+ m - interest ~ 15% [May vary] + 8% [merchant]
-   ~ w/ [ubi]
-   Repay - Streams cash to hux