[[Electrons-101]]

Erp with payroll
<mark style="background: #BBFABBA6;">
Streaming payroll { ex: 1000 a month - 1000/30 days = 33 daily }</mark>


<mark style="background: #BBFABBA6;">streaming per sec { certain amount per sec ex: 0.00000012 per sec }
</mark>


[[Atom ai]] Rpa will be integrated with ghost task management for automation 
- atom workforce

erp for every industries {business}

- phase equation - distribution ai manages spending,income,investing for companies
- [[Carbon🐳]] - profit circulation
- ghost x [[Sandwich]] -tools connections and building inhouse tools
- perks - companies for using ghost