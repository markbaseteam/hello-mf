# **Future <!>**
[[Phase 4 dpr]]
[[Systems to grow wealth]]
More and more tasks currently performed by people will be performed by software that can think and learn. More authority will be transferred from labour to capital.

Phase 4 Platforms will embrace this technological future and impose taxes on the assets that will account for the majority of value in that world—companies and land—in order to equitably share part of the ensuing prosperity.

>Ai will produce extraordinary wealth. Once sufficiently powerful AI "joins the workforce," the cost of many types of labour (which influences the costs of goods and services) will drop near zero.

To disperse this wealth and provide more people the chance to live the lives they want, the world will change so quickly and radically that a correspondingly drastic change in policy will be required. More than ever before, we can raise people's standards of life if we get both of them right.

ai will have extraordinary capacity to think, create, analyse, and reason will be at the centre of the impending change. We will add a fourth great technological revolution—the AI revolution—to the previous three, which are the agricultural, industrial, and computing.

Everyone will have access to adequate wealth as a result of this revolution. The technological progress we make in the next 100 years will be far larger than all we’ve made since we first controlled fire and invented the wheel. We have already built AI systems that can learn and do useful things. They are still primitive, but the trendlines are clear.

Due to the fact that human costs are a major factor at many supply chain stages, AI will reduce the price of goods and services.

A generation whose members can't afford what they want should use "phase 4" as their catchphrase. Although it seems like a fantasy, technology can actually make it happen (and in some cases already has).

Consider a world where, for decades, the cost of everything—housing, education, food, clothes, etc.—halved every two years.

Following a technological revolution, we constantly discover new occupations, and due to the abundance on the other side, we will have a lot of creative licence in determining what those occupations are. Economic inclusion refers to ensuring that everyone has a fair chance to have the means necessary to lead the life they choose.

Economic inclusiveness is important because it is just, results in a stable society, and can generate the biggest pieces of pie for the most individuals. Additionally, it results in greater growth. Because it compensates individuals for investing in long-term assets that increase in value, capitalism is a strong force behind economic progress.

This system works well to encourage the development and distribution of new technologies. Everyone will desire the globe to be better off if they own a piece of the global value creation: Making it possible for everyone to actively profit from capitalism as an equity owner is the greatest approach to enhance it.

As AI becomes more potent, it will become more realistic since there will be far more riches available. Companies, particularly ones that employ AI, and land, which has a fixed quantity, will be the two main sources of wealth.

The emphasis will be on creating "more good" rather than "less bad" in a society where everyone benefits from capitalism as an owner. These strategies are more unlike than they appear, and society benefits much from concentrating on the former.

Simply said, maximising for the largest pie and splitting it out as equitably as feasible correspond to more good and less evil, respectively. Both can raise people's standards of life once, but pie expansion is the only thing that leads to continual growth.

>Unstoppable changes are on the horizon. We may use them to build a far more equitable, joyous, and wealthy society if we accept them and prepare for them. The potential for the future is nearly beyond belief.

# Phase 4 🥬

-   **Framework to build universal basic income & services by monsters inc.**

# Phase 1

## [[xid]]

-   XiD 💻

# Phase 2

## [[Ghost]]

-   Ghost 👻

# Phase 3
## [[Atom ai]]

-   Atom 🤖

# Phase 4

## [[phase 4]]

-   Ubi 🦄 x 🦕

People who are crazy enough to think they can change the world are the ones who do. – Steve Jobs

# Research by

-   John luther 🕴
-   Zach 🧛‍♂️
-   Louis 🧙‍♂️ 💖 Jomia 🦆