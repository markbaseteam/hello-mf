  
    [[Electrons-101]]

## **Wallet** 🔩

-   Erc model physical wallet
-   Virtual cards
-   iot - feature
-   Custom cases [1st party & 3rd]
-   Additional Perks
-   Terb ecosystem

![[Glitch card dpr]]
 
 
 🧸

# **Card** 💳

-   Virtual cards
-   w/[🧇] designs
-   Perks


- ![[Virtual collection (nft)]]