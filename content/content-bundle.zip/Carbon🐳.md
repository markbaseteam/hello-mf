[[Electrons-101]]

## **Hexb based stock Market [assets]**

-   _Relist major companies from that exchange to carbon_
-   _Ai_
-   Growth / value badge on assets
-   _Pockets ~"_
-   _Interensic value_
