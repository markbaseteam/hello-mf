[[Electrons-101]]

## **👨‍🏭 Tiny house builder**

-   House - minimalist
-   Affordable & pay w/ ![[Hux]]
-   Sustainable
-   Heavy Interior design