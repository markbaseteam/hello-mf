[[Electrons-101]]

## **Restaurant**

-   _Kiosk based & normal_
-   healthy cause everybody will be smart ater 
    ubi-[[phase 4]]
-   _Sonneborn model - [ McDonald's]_
-   _Automated_
-   In house brands - for different types of foods 
    ~ burgers, fried chicken etc. Depends on geography
-   delivery option- [[Crate]]