[[Electrons-101]]

## **Equity investment [Pre ipo,seed, fractionalized] + tool for founders to pitch**

-   _Promote [social sharing] & investing_
-   _Fractionalized equity,bonds for startups_
-   _gets [[Virtual collection (nft)]] for investment equity_
-   _Incubator_
-   _Erp for startups_
-   Syndicate

# **Revenue streams**

-   _Equity_
-   _Aggregator commission [ bonds , equity]_

# **Research lab**

-   Research things (business)to implement in future
-   Funded by hexb [ business line ]