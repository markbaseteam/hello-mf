up::[[-!]]

## list of long term goals

An area of responsibility, by contrast, has a **standard** to be maintained. And there is no end date or final outcome. Your performance in this area may wax and wane over time, but the standard **continues indefinitely** and requires a certain level of attention at all times.