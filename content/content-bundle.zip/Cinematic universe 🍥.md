[[Electrons-101]]

# **Cinematic universe with fractionalized revenue**

-   _Perks for partners [Fans] who invested in fractionalized production_
-   _Movies_
-   _Cosmic based verse projects_
-   _Cinematic universe badge_
-   _Hoodies & merch[official] for team_