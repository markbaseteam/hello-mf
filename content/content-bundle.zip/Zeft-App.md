[[Electrons-101]]
[[Zeft atomic]] , [[zeft resources]], [[zeft payment spread]] ,[[zeft subscripiton dpr]]
# **What's zeft** 🪁

-   _**It's a digital microwork aggregator**_
    
    -   _What's a microworking platform - Microwork is a series of many small tasks which together comprise a large unified project, and it is completed by many people over the Internet_
    -   Types of works -

# **The Problem** 🛵

-   **#Problems of current microworking platforms**
    
    -   User identity verification [kyc]
    -   Bad ui [poor experience eventually stop using the platform]
-   🌋

-   **#Problems by payment system**
    
    -   _slow transactional speed_
    -   _High fees from banks and payment apps_

# **Solutions⚡**

-   **Potential Solutions**

    -   _Minimal ui_
    -   [XiD](https://www.taskade.com/v/v73ZUkGdHzEZg2X5 "XiD") _- [kyc]_
    -   _Payments in crypto_

# **Impact☄**

-   _So what we are doing will be we aggregate all the gigs/works and provide it to our users_
-   Its a win win for both - the team and users
-   blockchain [crypto] & [XiD](https://www.taskade.com/v/v73ZUkGdHzEZg2X5 "XiD")

# **Revenue streams**💸

-   [Payment spread](https://www.taskade.com/v/jb11b8JJgw9F2My5 "Payment spread")
-   [Crypto spread](https://www.taskade.com/v/yfnfR9R7pDfZVnbS "Crypto spread")
-   [Defi](https://www.taskade.com/v/iBHcnhvsGcP31xD2 "Defi")
-   [E-store](https://www.taskade.com/v/TSeYgW25C5mBwzeZ "E-store")

# **Influencer ad** []

-    Referral from the users that join zeft from them [partners]
-    Ex- 10% (may vary) from referred person's withdrawal - so the influencers market 
      the app 
-    high % first to boost users growth at launching time. Like an event {stoping after max users} [April 1 to 20 ~ full revenue % of business model to influencers]