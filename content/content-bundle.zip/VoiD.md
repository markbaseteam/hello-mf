[[Electrons-101]]

# Personal and public transport

-   🛴 🚌
-   With cargo compartment
-   [[Crate]] Pass xid

# `Void

-   Metaverse- vehicles
-   Modifications & custom design for vehicles - irl