[[Electrons-101]]

# **Subscription crate** 📦 (150 €)

-   _Netflix_
-   _Snacks_
-   _E-store membership_
-   _Tech_
-   Clothing
-   Must needed things (groceries,etc)
-   _Hardware [car,shoe]_ subscription
-   inhouse items
- ![[Crate atomic]]
# **Features** 🍭

-   _Customized crate_
-   _Virtual crate w/_ _[🧇]
-   _Subscription manager - All Subscriptions in crate so we can provide discount_